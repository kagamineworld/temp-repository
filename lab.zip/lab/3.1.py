from wordcloud import WordCloud
import jieba
#读取标点符号库
with open('18.txt','r',encoding='UTF-8') as f:
    text = f.read()
cut_text =" ".join(jieba.cut(text))
cloud = WordCloud(
    background_color="white", #背景颜色
    max_words=100, #显示最大词数
    font_path=" C:\\Windows\\Fonts\\STXINGKA.TTF",  #使用字体
    min_font_size=40,
    max_font_size=100, 
    width=800,  #图幅宽度
    height=400
    )
wCloud = cloud.generate(cut_text)
import matplotlib.pyplot as plt
plt.imshow(wCloud, interpolation='bilinear')
plt.axis('off')
plt.show()
